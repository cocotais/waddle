### 修改于 EatKano (https://github.com/arcxingye/EatKano)

# 原简介

<p align="center">
  <a href="https://xingye.me/game/eatkano"><img src="https://github.com/arcxingye/EatKano/blob/main/static/image/ClickBefore.png?raw=true" width="100" height="100" alt="EatKano"></a>
</p>
<div align="center">

# EatKano

_🦌 网页小游戏 🥛_

</div>


## 简介

小游戏：吃掉小鹿乃

[鹿乃b站](https://space.bilibili.com/316381099)
|
[线上版本](https://xingye.me/game/eatkano/index.php)
|
[Github Pages](https://arcxingye.github.io/EatKano/index.html)

## 可选功能

简易排行榜(日/周/月) 不推荐使用

不需要排行榜把php/sql文件都删掉即可

## 其它事项

点下star吧~ 欢迎pr代码

可修改和续写，需保留跳转此仓库的开源按钮

如整成自己想要的吃掉xxx，可以Fork一份改下图和字，并在github pages运行，不会请参考[视频教程](https://www.bilibili.com/video/BV1jT4y1y7kA)
