
CustomRenderer = function (name) {
	CustomRenderer.superClass_.constructor.call(this, name);
};
Blockly.utils.object.inherits(CustomRenderer,
	Blockly.blockRendering.Renderer);

CustomConstantsProvider = function () {
	// Set up all of the constants from the base provider.
	CustomConstantsProvider.superClass_.constructor.call(this);

	this.BLOCK_EDGE_WIDTH = 20
	this.BLOCK_EDGE_WIDTH_OUTPUT = 18
	this.BLOCK_EDGE_WIDTH_OUTPUT_HEXAGONAL = 12
	this.BLOCK_EDGE_WIDTH_SHADOW = 15
	this.BLOCK_EDGE_WIDTH_SHADOW_HEXAGONAL = 9
	this.BLOCK_EDGE_WIDTH_SHADOW_ROUND = 15
	this.BLOCK_LEFT_TOP = [0, 0]
	this.CENTER_CORNER_OFFSET = 2
	this.COLLAPSED_HEIGHT = 20
	this.COLLAPSED_PATH = "l 8,0 0,4 8,4 -16,8 8,4"
	this.COMMENT_PADDING_RIGHT = 8
	this.CORNER_OFFSET_X = 2
	this.CORNER_OFFSET_Y = 1
	this.CORNER_RADIUS = 2
	this.CORNER_RADIUS_END_BLOCK_WITHOUD_NOTCH = 12
	this.C_BLOCK_INNER_CORNOR_LEFT_BOTTOM = "a 2 2 0 0 0 2 2"
	this.C_BLOCK_INNER_CORNOR_LEFT_TOP = "a 2 2 0 0 0 -2 2"
	this.C_BLOCK_INNER_CORNOR_RADIUS = 2
	this.EXECUTION_GROUP_DECORATION_RIGHT_MARGIN = 8
	this.EXECUTION_GROUP_DECORATION_WIDTH = 124
	this.FIELD_HEIGHT = 30
	this.FLYOUT_CORNER_RADIUS = 0
	this.GROUP_BOTTOM_RIGHT_PATH = "a 4 4 0 0 1 -3.7 3.5"
	this.GROUP_EXTRA_ROW_RIGHT = "\n    h 61\n    a 4 4 0 0 1 3.5 1.7\n    l 7 12\n    a 4 4 0 0 1 -3.5 6.3\n  "
	this.GROUP_RIGHT_EDGE_WIDTH = 24
	this.GROUP_RIGHT_EXTENDED_WIDTH = 16
	this.GROUP_TOP_RIGHT_PATH = "a 4 4 0 0 1 3.7 5.5"
	this.HEAD_ICON_WIDTH = 38
	this.HEAD_ICON_WRAP_WIDTH = 48
	this.HEX_CENTER_CORNER_RADIUS = 2
	this.HEX_TOP_BOTTOM_CORNER_RADIUS = 3
	this.INLINE_PADDING_Y = 2
	this.INPUT_EXTRA_ROW_HEIGHT = 20
	this.INPUT_EXTRA_ROW_WIDTH = 86
	this.INPUT_MIN_HEIGHT_STATEMENT = 20
	this.INPUT_SHAPE_HEIGHT = 28
	this.INPUT_SHAPE_HEXAGONAL_WIDTH = 54
	this.INPUT_SHAPE_ROUND_WIDTH = 36
	this.MIN_HEIGHT = 40
	this.MIN_HEIGHT_OUTPUT = 36
	this.MIN_HEIGHT_SHADOW = 30
	this.MIN_WIDTH = 110
	this.MIN_WIDTH_OUTPUT = 40
	this.MIN_WIDTH_SHADOW = 40
	this.MIN_WIDTH_SHADOW_HEXAGONAL = 54
	this.NOTCH_CORNOR_LEFT_BOTTOM_1 = "a 3,3 0 0 0 2,1"
	this.NOTCH_CORNOR_LEFT_BOTTOM_2 = "a 3,3 0 0 1 -2,-1"
	this.NOTCH_CORNOR_LEFT_TOP_1 = "a 3,3 0 0 1 2,1"
	this.NOTCH_CORNOR_LEFT_TOP_2 = "a 3,3 0 0 0 -2,-1"
	this.NOTCH_CORNOR_RADIUS = 3
	this.NOTCH_CORNOR_RIGHT_BOTTOM_1 = "a 3,3 0 0 0 2,-1"
	this.NOTCH_CORNOR_RIGHT_BOTTOM_2 = "a 3,3 0 0 1 -2,1"
	this.NOTCH_CORNOR_RIGHT_TOP_1 = "a 3,3 0 0 1 2,-1"
	this.NOTCH_CORNOR_RIGHT_TOP_2 = "a 3,3 0 0 0 -2,1"
	this.NOTCH_HEIGHT = 4
	this.NOTCH_OFFSET_BETWEEN_PADDING_AND_ROUND_CORNER = 2
	this.NOTCH_PATH_LEFT = "a 3,3 0 0 1 2,1 l 4,4 a 3,3 0 0 0 2,1 h 6 a 3,3 0 0 0 2,-1 l 4,-4 a 3,3 0 0 1 2,-1"
	this.NOTCH_PATH_RIGHT = "a 3,3 0 0 0 -2,1 l -4,4 a 3,3 0 0 1 -2,1 h -6 a 3,3 0 0 1 -2,-1 l -4,-4 a 3,3 0 0 0 -2,-1"
	this.NOTCH_WIDTH = 20
	this.NOTCH_WIDTH_SHORT = 6
	this.NOTCH_WIDTH_SIDE = 4
	this.NTOCH_START_PADDING = 13
	this.OUTPUT_GROUP_DECORATION_OFFSET = 6
	this.OUTPUT_GROUP_DECORATION_PADDING = 14
	this.OUTPUT_ROW_PADDING_Y_TO_FIELD = 3
	this.OUTPUT_ROW_PADDING_Y_TO_VALUE_BLOCK = 2
	this.ROW_PADDING = 16
	this.ROW_PADDING_HEAD = 19
	this.ROW_PADDING_OUTPUT = 18
	this.ROW_PADDING_OUTPUT_NON_TEXT = 0
	this.ROW_PADDING_OUTPUT_WITH_INPUT = 16
	this.ROW_PADDING_OUTPUT_WITH_TEXT = 16
	this.ROW_PADDING_SHADOW = 15
	this.SEP_SPACE_X = 8
	this.SHADOW_FIELD_HEIGHT = 17.5
	this.SHADOW_ROW_PADDING_Y_TO_FIELD = 0
	this.STATEMENT_FIRST_ROW_MIN_WIDTH = 110
	this.STATEMENT_MIN_WIDTH = 16
	this.STATEMENT_OTHER_ROW_MIN_WIDTH = 86
	this.STATEMENT_ROW_PADDING_Y_TO_FIELD = 5
	this.STATEMENT_ROW_PADDING_Y_TO_STATEMENT_BLOCK = 0
	this.STATEMENT_ROW_PADDING_Y_TO_VALUE_BLOCK = 4
	this.TEXT_MIN_WIDTH_IN_FIELD = 20
	this.TEXT_PADDING_IN_FIELD = 8
	this.VALUE_SHAPE_EDGE_WIDTH = 15
	this.VALUE_SHAPE_HEIGHT = 30
	this.VALUE_SHAPE_HEXAGONAL = "M 15,0  H 39 L 54,60 l -15,60 H 15 L NaN15 L 15,0 z"
	this.VALUE_SHAPE_ROUND = "M 15,0 H 39 a 15 15 0 0 1 0 30 H 15 a 15 15 0 0 1 0 -30 z"
	this.VALUE_SHAPE_WIDTH = 54
};

Blockly.utils.object.inherits(CustomConstantsProvider,
	Blockly.blockRendering.ConstantProvider);

CustomRenderer.prototype.makeConstants_ = function () {
	return new CustomConstantsProvider();
};



Blockly.blockRendering.register('custom_renderer', CustomRenderer);
