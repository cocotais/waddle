/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview JavaScript Generator module; just a wrapper for
 *     javascript_compressed.js.
 */
